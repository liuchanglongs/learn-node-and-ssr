const prerender = require('prerender')
const server = prerender({
  chromeLocation: 'C:/Program Files/Google/Chrome/Application/chrome.exe',
  port: 4000, // 更改prerender服务器端口
})
//使用prerender插件
server.use(prerender.removeScriptTags())
server.start()

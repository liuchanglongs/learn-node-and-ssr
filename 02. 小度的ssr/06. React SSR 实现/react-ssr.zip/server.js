import express from 'express'
import fs from 'node:fs/promises'

const port = 5173
const app = express()

const { createServer } = await import('vite')

const vite = await createServer({
  server: { middlewareMode: true },
  appType: 'custom'
})
app.use(vite.middlewares)
app.use('*all', async (req, res) => {
  const url = req.originalUrl
  let template = await fs.readFile('./index.html', 'utf-8')
  template = await vite.transformIndexHtml(url, template)
  const rendered = (await vite.ssrLoadModule('./src/entry-server.jsx')).render()
  const html = template.replace('<!--app-html-->', rendered.html)
  res.status(200).set({'Content-Type': 'text/html'}).send(html)
})

app.listen(port, () => {
  console.log(`server started at http://localhost:${port}`)
})


import express from 'express'
import fs from 'node:fs/promises'
import { Transform } from 'node:stream'

const port = 5173
const app = express()

const { createServer } = await import('vite')

const vite = await createServer({
  server: { middlewareMode: true },
  appType: 'custom',
})
app.use(vite.middlewares)
app.use('*all', async (req, res) => {
  const url = req.originalUrl
  let template = await fs.readFile('./index.html', 'utf-8')
  template = await vite.transformIndexHtml(url, template)
  let didError = false
  const rendered = (await vite.ssrLoadModule('./src/entry-server.jsx')).render({
    onShellReady() {
      res.status(didError ? 500 : 200)
      res.set({ 'Content-Type': 'text/html' })
      const transfromStream = new Transform({
        transform(chunk, encoding, callback) {
          res.write(chunk, encoding)
          callback()
        }
      })
      const [htmlStart, htmlEnd] = template.split('<!--app-html-->')
      res.write(htmlStart)
      rendered.pipe(transfromStream)
      transfromStream.on('finish', () => {
        res.end(htmlEnd)
      })
    },
    onShellError() {
      res.status(500)
      res.set({'Content-Type': 'text/html'})
      res.send('<h1>Something went wrong</h1>')
    },
    onError(error) {
      didError = true
      console.log(error)
    }
  })
})

app.listen(port, () => {
  console.log(`server started at http://localhost:${port}`)
})

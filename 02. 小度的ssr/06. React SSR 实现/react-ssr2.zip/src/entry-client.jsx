import { StrictMode } from 'react'
import './index.css'
import App from './App.jsx'
import { hydrateRoot } from 'react-dom/client'

hydrateRoot(document.getElementById('root'), 
 <StrictMode>
  <App />
 </StrictMode> 
)
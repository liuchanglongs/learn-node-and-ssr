import { StrictMode } from 'react'
import { renderToPipeableStream } from 'react-dom/server'
import App from './App.jsx'

export function render(options) {
  const { pipe } = renderToPipeableStream(
    <StrictMode>
      <App />
    </StrictMode>,
    options
  )
  return { pipe }
}
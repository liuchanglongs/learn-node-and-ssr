import { StrictMode } from 'react'
import { renderToPipeableStream } from 'react-dom/server'
import App from './App.jsx'

export function render(options, props) {
  const { pipe } = renderToPipeableStream(
    <StrictMode>
      <App {...props} />
    </StrictMode>,
    options
  )
  return { pipe }
}
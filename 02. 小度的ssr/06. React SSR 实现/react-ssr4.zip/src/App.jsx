import { Suspense, lazy } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'

const Card = lazy(() => import('./Card.jsx'))

function App({ data }) {
  return (
    <>
      <div>
        <a href="https://vite.dev" target="_blank">
          <img src={viteLogo} className="logo" alt="Vite logo" />
        </a>
        <a href="https://react.dev" target="_blank">
          <img src={reactLogo} className="logo react" alt="React logo" />
        </a>
      </div>
      <h1>Vite + React</h1>
      <p>{ JSON.stringify(data) }</p>
      <Suspense fallback={<p>Loading card component ...</p>}>
        <Card />
      </Suspense>
      <p className="read-the-docs">
        Click on the Vite and React logos to learn more
      </p>
    </>
  )
}

export async function getServerSideProps() {
  const res = await fetch('http://jsonplaceholder.typicode.com/todos/1')
  const data = await res.json()
  return { props: { data } }
}

export default App

import { StrictMode } from 'react'
import './index.css'
import App from './App.jsx'
import { hydrateRoot } from 'react-dom/client'

const props = window.__INITIAL_PROPS__

hydrateRoot(document.getElementById('root'), 
 <StrictMode>
  <App {...props} />
 </StrictMode> 
)
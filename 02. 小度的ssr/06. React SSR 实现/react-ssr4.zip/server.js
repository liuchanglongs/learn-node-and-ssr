import express from 'express'
import fs from 'node:fs/promises'
import { Transform } from 'node:stream'
import process from 'node:process'

const isProduction = process.env.NODE_ENV === 'production'
const port = isProduction ? 4173 : 5173
const app = express()

const { createServer } = await import('vite')

if (isProduction) {
  const sirv = (await import('sirv')).default
  app.use('/', sirv('./dist/client', { extensions: [] }))
}

const vite = await createServer({
  server: { middlewareMode: true },
  appType: 'custom',
})
app.use(vite.middlewares)
app.use('*all', async (req, res) => {
  const url = req.originalUrl
  let didError = false
  let template
  let render 
  if (isProduction) {
    template = await fs.readFile('./dist/client/index.html', 'utf-8')
    render = (await import('./dist/server/entry-server.js')).render
  } else {
    template = await fs.readFile('./index.html', 'utf-8')
    template = await vite.transformIndexHtml(url, template)
    render = (await vite.ssrLoadModule('./src/entry-server.jsx')).render
  }
  
  const getServerSideProps = (await vite.ssrLoadModule('./src/App.jsx')).getServerSideProps
  const props = getServerSideProps ? (await getServerSideProps()).props : {}

  const rendered = render({
    bootstrapScriptContent: `window.__INITIAL_PROPS__=${JSON.stringify(props)}`,
    onShellReady() {
      res.status(didError ? 500 : 200)
      res.set({ 'Content-Type': 'text/html' })
      const transfromStream = new Transform({
        transform(chunk, encoding, callback) {
          res.write(chunk, encoding)
          callback()
        }
      })
      const [htmlStart, htmlEnd] = template.split('<!--app-html-->')
      res.write(htmlStart)
      rendered.pipe(transfromStream)
      transfromStream.on('finish', () => {
        res.end(htmlEnd)
      })
    },
    onShellError() {
      res.status(500)
      res.set({'Content-Type': 'text/html'})
      res.send('<h1>Something went wrong</h1>')
    },
    onError(error) {
      didError = true
      console.log(error)
    }
  }, props)
})

app.listen(port, () => {
  console.log(`server started at http://localhost:${port}`)
})
